package hubtest;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
/**
 *
 * @author Dan Lee
 */
public class Class {
    
    public static void appendClass() throws IOException
    {
        File classFile = new File("class.txt");
        FileWriter fileWriter = new FileWriter(classFile, true);
        BufferedWriter buffer = new BufferedWriter(fileWriter);
        try (PrintWriter printWriter = new PrintWriter(buffer)) {
            if (classFile.exists() == false)
            {
                classFile.createNewFile();
            }
            
            printWriter.printf("%s%n", GUICommand.combineClassWCredit());
            printWriter.close();
        }
        
    }
    
    public static void resetClass() throws IOException
    {
        PrintWriter printWriter = new PrintWriter("class.txt");
        printWriter.close();
        
    }
}

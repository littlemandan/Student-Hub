package hubtest;
import java.io.FileNotFoundException;
import java.lang.SecurityException;
import java.util.Formatter;
import java.util.FormatterClosedException;
import java.util.NoSuchElementException;
import java.util.Scanner;
/**save name
 *create text files, save data
 * @author Dan Lee
 * nov 24 2017
 * NOTE: this class contains open/save methods that are not for name data
 */
public class SaveName
{
    private static Formatter output;
    
    public static void openSaveNameFile() //creates and opens file
    {
        try
        {
            output = new Formatter("name.txt");
        }
        catch (SecurityException securityException)
        {
            System.err.println("Write permission denied. Terminating.");
            System.exit(1);
        }
        catch (FileNotFoundException fileNotFoundException)
        {
            System.err.println("Error opening file. Terminating.");
            System.exit(1);
        }
    }
    
    public static void addName(String sName)
    {
        
        try
        {
        output.format("%s", sName);
        }
        catch (FormatterClosedException formatterClosedException)
        {
            System.err.println("Error writing to file. Terminating");
        }
        catch (NoSuchElementException elementException)
        {
            System.err.println("Invalid input");
        }
    }
    
    public static void closeFile()
    {
        output.close();
    }
    
    
    
    public static void addGPA(String sGPA)
    {
        
        try
        {
        output.format("%s", sGPA);
        }
        catch (FormatterClosedException formatterClosedException)
        {
            System.err.println("Error writing to file. Terminating");
        }
        catch (NoSuchElementException elementException)
        {
            System.err.println("Invalid input");
        }
    }
    
    public static void createGPAFile()
    {
        try
        {
            output = new Formatter("gradepointaverage.txt");
        }
        catch (SecurityException securityException)
        {
            System.err.println("Write permission denied. Terminating.");
            System.exit(1);
        }
        catch (FileNotFoundException fileNotFoundException)
        {
            System.err.println("Error opening file. Terminating.");
            System.exit(1);
        }
    }
    
}
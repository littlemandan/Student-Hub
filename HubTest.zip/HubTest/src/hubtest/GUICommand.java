package hubtest;
import java.io.IOException;
import java.lang.NumberFormatException;
/**
 *
 * @author Dan Lee
 */
public class GUICommand {
    
    private static String OS = System.getProperty("os.name").toLowerCase();
    
    public static void openLoginScreen()
    {
       LoginScreen loginScreen = new LoginScreen();
       loginScreen.setVisible(true);
    }
            
    public static void openMainMenu()
    {
        MainMenu mainMenu = new MainMenu();
        mainMenu.setVisible(true);
        MainMenu.GPAlbl.setText(ReadInfo.openGPAFile());
        
    }
    
    public static void openGPACalculator()
    {
        GPACalculator gpaCalculator = new GPACalculator();
        gpaCalculator.setVisible(true);
    }
    
    public static Double validateGPA(String sX)
    {
        double x = 0.0;
        try
        {
            if (sX != null && sX.trim().isEmpty()) //takes care of no input exception
                x = 0.0;
            else 
                x = Double.parseDouble(sX);

        }
        catch (NumberFormatException numberFormatException)
        {
            System.err.printf("%nException: %s%n", numberFormatException);
            GPACalculator.errorlbl.setText("Enter integers only.");
        }
        return x;
    }
    public static boolean validateUsername()
    {
        return LoginScreen.NameTxtField.getText().trim().isEmpty();
    }
    
   public static String validateCredit(String sCredit)
   {
       double credit;
       String validatedCredit = null;
        try
        {
            if (sCredit != null && sCredit.trim().isEmpty()) //takes care of no input exception
            {               
                InputClass.creditErrorLbl.setText("Empty Field.");
                validatedCredit = ("___");
            }
            else if (isNumeric(sCredit) == true)
            {
                credit = Double.parseDouble(sCredit);
                sCredit = String.format("%.02f", credit);
                validatedCredit = sCredit;
            }
            else
                InputClass.creditErrorLbl.setText("Try Again.");
        }
        catch (NumberFormatException numberFormatException)
        {
            InputClass.creditErrorLbl.setText("Try Again.");
        }
        return validatedCredit;
        
   }
   
    public static void resetData() throws IOException
    {
        SaveName.openSaveNameFile();
        SaveName.addName("default");
        SaveName.closeFile();
        SaveName.createGPAFile();
        SaveName.addGPA("N/A");
        SaveName.closeFile();
        Class.resetClass();
    }
    
    public static void openInputClass()
    {
        InputClass inputClass = new InputClass();
        inputClass.setVisible(true);
    }
    
    public static void returnToMain()
    {
        String sName;
        sName = ReadInfo.openNameFile();
        ReadInfo.closeFile();
        MainMenu mainMenu = new MainMenu();
        MainMenu.NameLabel.setText(sName+ ".");
        String sGPA;
        sGPA = ReadInfo.openGPAFile();
        ReadInfo.closeFile();
        MainMenu.GPAlbl.setText(sGPA);
        mainMenu.setVisible(true);
    }
    
    public static String combineClassWCredit()
    {
        String sClass = InputClass.classTextField.getText().replaceAll("\\s","");
        String sCredit = validateCredit(InputClass.creditTextField.getText()).replaceAll("\\s", "");
        String combinedClass;
        combinedClass = sClass.concat((" ").concat(sCredit));
        return combinedClass;
    }
    
    public static boolean isNumeric(String str)
    {
        try  
    {  
        double d = Double.parseDouble(str);  
    }  
        catch(NumberFormatException nfe)  
    {  
        return false;  
    }  
  return true;  
    }
    
    public static void openReport() throws IOException
    {
        ProcessBuilder pb = new ProcessBuilder();
        if (OS.indexOf("win") >= 0){  //is Windows
            pb = new ProcessBuilder("Notepad.exe", "class.txt");
        }
        else{  // is mac 
            String cmd = "/Applications/TextEdit.app";
            pb = new ProcessBuilder("open","-a", cmd, "class.txt");
        }
        pb.start();
    }
}
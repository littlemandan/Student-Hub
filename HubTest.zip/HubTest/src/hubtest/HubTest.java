package hubtest;

/**
 *  
 * @author Dan Lee
 */
public class HubTest {

    
    public static void main(String[] args) 
    {
       if (ReadInfo.validateName() == true || ReadInfo.openNameFile().equals("default"))
       {
           GUICommand.openLoginScreen();
       }
       else
       {GUICommand.openMainMenu();
       MainMenu.NameLabel.setText(ReadInfo.openNameFile()+ ".");
       }   
          
       
    }
        
    
}

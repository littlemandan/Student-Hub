package hubtest;
import javax.swing.JFrame;
import java.util.Scanner;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.NoSuchElementException;
/**
 *
 * @author Dan Lee
 * NOTE: this class contains open/read methods that are not for name data
 */

public class ReadInfo {
    private static Scanner input;
    
    public static String openNameFile()
        {
            try
            {
            input = new Scanner(Paths.get("name.txt"));
            }
            catch (IOException ioException)
            {
                System.err.println("Error opening file. Terminating.");
                System.exit(1);

            }
            String sName = input.next();
            return sName;
        }
    public static boolean validateName()
    {
        try
        {
        return openNameFile().length() == 0; //placeholder to catch the exception
        }
        catch (NoSuchElementException noSuchElementException)
        {
            return true;
        }
    }
    public static String openGPAFile()
        {
            try
            {
            input = new Scanner(Paths.get("gradepointaverage.txt"));
            }
            catch (IOException ioException)
            {
                System.err.println("Error opening file. Terminating.");
                System.exit(1);

            }
            String sGPA = input.next();
            return sGPA;
        }
    

    public static void closeFile()
    {
        input.close();
    }

}
